package br.com.hunter7210.flutter_check_in_events

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
