package com.example.exemplo_firebase

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
