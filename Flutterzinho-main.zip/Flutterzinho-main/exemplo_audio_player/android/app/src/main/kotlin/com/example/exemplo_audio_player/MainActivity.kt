package com.example.exemplo_audio_player

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
