# exemplo_audio_player

A new Flutter project.


Exemplo_Audio_Player
    Model
        audioModel
    Service
        audioService (Lista de audios - Json)
    Screen
        HomeScreen - VIEW Lista de audios
        AudioPlayerScreen - Player de audios 
        (biblioteca)
    
    